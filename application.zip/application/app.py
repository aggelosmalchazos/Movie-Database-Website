# ----- CONFIGURE YOUR EDITOR TO USE 4 SPACES PER TAB ----- #
import sys,os
sys.path.append(os.path.join(os.path.split(os.path.abspath(__file__))[0], 'lib'))
import pymysql

def connection():
    ''' User this function to create your connections '''    
    con = pymysql.connect(host='localhost', port=3306, user='root', passwd='passwd', db='movies') #update with your settings
     
    return con

def updateRank(rank1, rank2, movieTitle):

    # Create a new connection
    con=connection()

    # Create a cursor on the connection
    cur=con.cursor()

    try:
        float(rank1)
    except ValueError:
        return [("status",),("error",),]
    try:
        float(rank2)
    except ValueError:
        return [("status",),("error",),]
    rank1=float(rank1)
    rank2=float(rank2)
    if not(0 <= rank1 <= 10) or not(0 <= rank2 <= 10):
        
        print (rank1, rank2, movieTitle)
        return [("status",),("error because of value range",),]

    #execute sql statement
    try:
        cur.execute("SELECT movie_id, `rank` FROM movie WHERE title =%s ", (movieTitle,))
        rows = cur.fetchall()

        if len(rows) != 1:
            result = [("status",), ("error because no movie or many movies",)]
        else:
            movie_id, current_rank = rows[0]
        # Calculate the new rank
        if current_rank is None:
            new_rank = (rank1 + rank2) / 2
        else:
            new_rank = (current_rank + rank1 + rank2) / 3
        print(new_rank)
        # Update the movie's rank in the database
        cur.execute("UPDATE movie SET `rank` = %s WHERE movie_id = %s", (new_rank, movie_id))
        con.commit()
    
        result = [("status",), ("ok",)]
    except Exception as e:
        print("error:", e)  # Print the reason for the exception
        result = [("status",), ("error",), ("message", str(e))]  # Include the exception message in the result

    return result

def colleaguesOfColleagues(actorId1, actorId2):
    if actorId1 is None or actorId2 is None:
        return [("error",),("input is not 2 actors",),]
    
    if actorId1==actorId2:
        return [("error",),("input is same actor",),]

    # Create a new connection
    con=connection()


    # Create a cursor on the connection
    cur=con.cursor()
    #Select all the movies c and d have played in together(fmcd), if c has played in a movie with a(mac) and b has played in a movie with d(mdb)   
    sqlquery = """
    SELECT distinct a.actor_id as a_actor, b.actor_id as b_actor, c.actor_id as c_actor, d.actor_id as d_actor, fmcd.title as movie_title
    FROM role a, role b, role c, role d, movie fmcd 
    WHERE
        a.actor_id =%s AND b.actor_id = %s  
        AND c.actor_id <> a.actor_id AND d.actor_id <> b.actor_id
        AND c.actor_id<>b.actor_id AND d.actor_id<>a.actor_id
        AND c.actor_id <> d.actor_id
        AND fmcd.movie_id=c.movie_id
        AND fmcd.movie_id=d.movie_id
        AND a.movie_id IN (
            SELECT mac.movie_id
            FROM role mac
            WHERE mac.actor_id = c.actor_id
        )
        AND b.movie_id IN (
            SELECT mdb.movie_id
            FROM role mdb
            WHERE mdb.actor_id = d.actor_id
        )
        ORDER BY fmcd.title;
    """
    try:
        cur.execute(sqlquery, (actorId1,actorId2))
        rows=cur.fetchall()
       
        # Initialize the list to store formatted results
        results = [("movieTitle", "colleagueOfActor1", "colleagueOfActor2", "actor1", "actor2")]


        # Iterate over each row and format the results
        for row in rows:
            movie_title = row[4]
            colleague_of_actor1 = row[2]
            colleague_of_actor2 = row[3]
            actor1 = row[0]
            actor2 = row[1]
            results.append((movie_title, colleague_of_actor1, colleague_of_actor2, actor1, actor2))


        # Return the formatted results
        return results
    except Exception as e:
        print("error: ",e)

def actorPairs(actorId):

    if actorId is None:
        return [("error",),]

    # Create a new connection
    con=connection()

    # Create a cursor on the connection
    cur=con.cursor()
    #selects the r1.actor_id, which has appeared with the given actor in at least 7 common movie genres
    #and has not appeared in movies of different genres without the participation of that actor.
    sql="""
        SELECT DISTINCT r1.actor_id
        FROM role r1, movie_has_genre mg1, role r2, movie_has_genre mg2
        WHERE r1.movie_id = mg1.movie_id
        AND r2.movie_id = mg2.movie_id
        AND r1.actor_id <> r2.actor_id
        AND r2.actor_id = %s
        AND r1.actor_id IN(        
	        SELECT r3.actor_id
	        FROM role r3, movie_has_genre mg3, role r4, movie_has_genre mg4
	        WHERE r3.movie_id = mg3.movie_id
	        AND r4.movie_id = mg4.movie_id
	        AND r3.movie_id = r4.movie_id
            AND r3.actor_id <> r4.actor_id
            AND r4.actor_id = %s
            AND mg3.genre_id = mg4.genre_id
            GROUP BY r3.actor_id
            HAVING COUNT(DISTINCT mg3.genre_id) >= 7
	    ) 
        AND NOT EXISTS (
            SELECT m2.movie_id
            FROM movie m2, genre g2, movie_has_genre mg2, role r3
            WHERE r1.actor_id = r3.actor_id 
            AND m2.movie_id = r3.movie_id 
            AND m2.movie_id = mg2.movie_id 
            AND g2.genre_id = mg2.genre_id 
            AND mg1.genre_id <> g2.genre_id 
            AND NOT EXISTS ( 
		        SELECT *
                FROM role r4
                WHERE r4.actor_id = r2.actor_id 
                AND r4.movie_id = m2.movie_id
		    )
	    )
        ORDER BY r1.actor_id ASC;"""

    try:
        cur.execute(sql, (actorId, actorId))
        rows=cur.fetchall()
       
        # Initialize the list to store formatted results
        results = [("actorID",)]


        # Iterate over each row and format the results
        for row in rows:
            actor = row[0]
            results.append((actor,))

        # Return the formatted results
        return results
    except Exception as e:
        print("error: ",e)

def selectTopNactors(n):
    n=int(n)
    if n<=0:
    
        return [("status",),("error because of value range",),]
    # Create a new connection
    con=connection()

    # Create a cursor on the connection
    cur=con.cursor()
    #returns the count, ordered by genre, movie count, actor 
    sql_query = """
    SELECT a.actor_id, g.genre_name, COUNT(mg.movie_id) as movie_count
    FROM actor a, role r, genre g, movie_has_genre mg
    WHERE a.actor_id = r.actor_id
    AND r.movie_id = mg.movie_id
    AND g.genre_id = mg.genre_id
    GROUP BY a.actor_id, g.genre_name
    ORDER BY g.genre_name, movie_count DESC, a.actor_id;
    """
    try:
        cur.execute(sql_query)
        results = cur.fetchall()
        if results is None:
            print("No results found.")
        current_genre = None
        count = 0
        actors = [("genreName", "actorId", "numberOfMovies")]
        for row in results:
            actor_id, genre_name, movie_count = row
            if genre_name != current_genre:
                current_genre = genre_name
                count = 0
            if count < n:
                actors.append((genre_name, actor_id, movie_count))
                count += 1
        return actors
    except Exception as e:
        print("error: ",e)

def traceActorInfluence(actorId):
    # Create a new connection
    con=connection()

    # Create a cursor on the connection
    cur=con.cursor()

    sql = "select * from role"
    try:
        cur.execute(sql,)
    except:
        print("error")

    return [("influencedActorId",),]
