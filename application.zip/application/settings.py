# MySQL Settings
mysql_host = '127.0.0.1'
mysql_port = 3306  # must be integer (this is wrong:'3306')
mysql_user = 'root' #must replace with your own settings
mysql_passwd = ''
mysql_schema = ''

# Webserver Settings
# IMPORTANT: The port must be available.
web_port = 8080  # must be integer (this is wrong:'8080')
